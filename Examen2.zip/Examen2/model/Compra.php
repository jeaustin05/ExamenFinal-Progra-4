<?php

namespace model;

class CCompra
{
    private $nombreCompleto;
    private $cedula;
    private $direccion;
    private $telefono;
    private $listaArticulos = [];

    public function __construct() 
    { 

    }

    public function getNombreCompleto()
    {
        return $this->nombreCompleto;
    }
    public function getCedula()
    {
        return $this->cedula;
    }
    public function getDireccion()
    {
        return $this->direccion;
    }
    public function getListaArticulos()
    {
        return $this->listaArticulos;
    }
    public function getTelefono()
    {
        return $this->telefono;
    }
    public function setNombreCompleto($nombreCompleto)
    {
        $this->nombreCompleto = $nombreCompleto;
    }
    public function setCedula($cedula)
    {
        $this->cedula = $cedula;
    }
    public function setDireccion($direccion)
    {
        $this->direccion = $direccion;
    }
    public function setListaArticulos($listaArticulos)
    {
        $this->listaArticulos = $listaArticulos;
    }
    public function setTelefono($telefono)
    {
        $this->telefono = $telefono;
    }
}
?>