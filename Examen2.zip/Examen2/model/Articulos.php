<?php
namespace model;

class CArticulo
{
    private $nombre;
    private $precio;
    private $descripcion;
    private $iva;
    private $cantidad;

    public function __construct() { }

    public function getNombre()
    {
        return $this->nombre;
    }
    public function getPrecio()
    {
        return $this->precio;
    }
    public function getDescripcion()
    {
        return $this->descripcion;
    }
    public function getIva()
    {
        return $this->iva;
    }
    public function getcantidad()
    {
        return $this->cantidad;
    }
    public function setNombre($nombre)
    {
        $this->nombre = $nombre;
    }
    public function setPrecio($precio)
    {
        $this->precio = $precio;
    }
    public function setDescripcion($descripcion)
    {
        $this->descripcion = $descripcion;
    }
    public function setIva($iva)
    {
        $this->iva = $iva;
    }
    public function setCantidad($cantidad)
    {
        $this->iva = $cantidad;
    }
}
