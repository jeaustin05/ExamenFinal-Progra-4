<?php
namespace controller;

interface BaseController {

    public function show();
//    public function save();
//    public function update();
//    public function delete();

}
