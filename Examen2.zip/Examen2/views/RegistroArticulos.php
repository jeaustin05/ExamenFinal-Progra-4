<!DOCTYPE html>
<html lang="en">

<head>
  
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.2/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <title>Registro de Articulos</title>
</head>

<body background="carrito.jpg">
    <center><h1>Registro de Articulos</h1></center>
    <form class="form-horizontal" action="index.php" method="get">
    <div class="form-group">
    <p>Nombre del articulo: <input type="text" name="nombre" placeholder="Ingrese el nombre del articulo" size="40"></p>
    <p>Precio: <input type="text" name="precio" placeholder="Ingrese el precio del articulo" size="25"></p>
    <p>Descripcion: <input type="text" name="descripcion" placeholder="Ingrese la descripcion del articulo" size="60"></p>
    <p>Incluye(IVA):
        <input type="radio" name="si" value="true"> si
        <input type="radio" name="no" value="false"> no
        </div>
        <p>
        <input type="submit" value="Guardar">
        <input type="reset" value="Borrar">
    </p>
    </form>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.15.0/umd/popper.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
    
</body>

</html>