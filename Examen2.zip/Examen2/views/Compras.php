<!DOCTYPE html>
<html lang="en">

<head>
  
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <title>Registro de Articulos</title>
</head>

<body background="carrito.jpg">
    <center><h1>Compra de Articulos</h1></center>
    <form class="form-horizontal" action="index.php" method="get">
    <div class="form-group">
    <p>Nombre del Cliente: <input type="text" name="nombre" placeholder="Ingrese su nombre" size="40"></p>
    <p>Cedula del Cliente: <input type="text" name="nombre" placeholder="Ingrese su cedula" size="40"></p>
    <p>Fecha: <input id="date" type="date"></p>
    <p>Articulo 1: <input type="text" name="art1" placeholder="Ingrese nombre del articulo" size="40"> <input type="number" name="cantidad" placeholder="Ingrese la cantidad"></p>
    <p>Articulo 2: <input type="text" name="art2" placeholder="Ingrese nombre del articulo" size="40"> <input type="number" name="cantidad" placeholder="Ingrese la cantidad"></p>
    <p>Articulo 3: <input type="text" name="art3" placeholder="Ingrese nombre del articulo" size="40"> <input type="number" name="cantidad" placeholder="Ingrese la cantidad"></p>
    <p>Articulo 4: <input type="text" name="art4" placeholder="Ingrese nombre del articulo" size="40"> <input type="number" name="cantidad" placeholder="Ingrese la cantidad"></p>
    <p>Articulo 5: <input type="text" name="art5" placeholder="Ingrese nombre del articulo" size="40"> <input type="number" name="cantidad" placeholder="Ingrese la cantidad"></p>
    <p>Articulo 6: <input type="text" name="art6" placeholder="Ingrese nombre del articulo" size="40"> <input type="number" name="cantidad" placeholder="Ingrese la cantidad"></p>
    <p>Articulo 7: <input type="text" name="art7" placeholder="Ingrese nombre del articulo" size="40"> <input type="number" name="cantidad" placeholder="Ingrese la cantidad"></p>
        
        <input type="submit" value="Guardar">
        <input type="reset" value="Borrar">
    </p>
    </form>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    
</body>

</html>