<?php
require_once 'vendor/autoload.php';

require_once("views/principal.php");

//session_start();

//use controller\ArticulosController;

//$uri = explode("/", $_SERVER['REQUEST_URI']);

//if (!isset($_GET['page']))
//    die('imposible de encontrar la ruta.');

//$artController = ArticulosController::getInstance();
//switch ($_GET['page']) {
    
 //   case 'principal':
 //       require_once($artController->createArticulos($_GET['articulos']) . ".php");
 //      break;

 //   default:
 //       require_once($artController->show() . ".php");
 //       break;
//}
